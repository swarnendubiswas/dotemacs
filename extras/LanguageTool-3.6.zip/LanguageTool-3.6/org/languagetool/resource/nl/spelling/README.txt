The dictionary was made as follows:

- a > 5 million words list from a real life Dutch corpus (by TaalTik) was used
- which was filtered for words accepted by the OpenTaal 2.10 spelling using Hunspell
- was cleaned from redundant forms (uppercased etc.)
- received some manual tweaking because of the difference in functionality between
  Hunspell and the Morfologik speller

We are aware that this list contains some errors as well as very rare words.

License:
This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

TaalTik, Ruud Baars, 2014-09-22
We would be glad to receive improvement suggestions at info*at*taaltik.nl

