
tl_PH.dict contains frequency information. This is licensed as follows:

SpellOnIt word frequency lists by SpellOnIt.com is licensed under a Creative Commons Attribution 4.0 International License.
Based on a work at http://www.spellonit.com/downloads.
