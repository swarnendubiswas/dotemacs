This is a Portuguese (Portugal) dictionary for Hunspell:

Copyright (C) 2006-2012  Jos� Jo�o de Almeida <jj@di.uminho.pt> , 
	Rui Vilela <ruivilela@di.uminho.pt> ,
	Alberto Sim�es <ambs@di.uminho.pt>

Dep. Inform�tica, Universidade do Minho
Portugal

All dictionary files and associated programs are currently covered by
the (GPL/LGPL/MPL), by this order. See also COPYING file for more
details, if available.

Regarding license versions: 
     1. GPL Version 2
     2. LGPL Version 2.1
     3. MPL Version 1.1

To install : Find a suitable application that uses myspell
    dictionaries like openoffice, or hunspell terminal aplication. Use
    the program dictionary application (if it has) for installing the
    dictionaries.  For openoffice, you should make sure that the
    dictionary.lst file has the following line: DICT pt PT pt_PT

Automatic instalation: You can automatically download our dictionary
using the available plugins, either from mozilla, or OpenOffice. See
our site for details.

Latest versions, suggestions, automatic install, informations at
       http://natura.di.uminho.pt/


