[source: http://extensions.libreoffice.org/extension-center/german-de-de-frami-dictionaries]

Bei dem Wörterbuch xxx_frami handelt es sich um ein Addon. Es enthält
alle Wörter des Basiswörterbuchs, zusätzlich jedoch etliche, die entweder
im Basiswörterbuch noch fehlen oder die nicht unbedingt zum Kernwortschatz
des Deutschen gehören. Die zusätzlichen Aufnahmen sind ungeprüft.
Dieses Wörterbuch basiert auf dem igerman98 Ispell-Wörterbuch, zu finden
unter http://www.j3e.de/ispell/igerman98/ .

Das Wörterbuch und alle enthaltenen Wortlisten sind lizenziert unter der
GNU GPL, Version 2 oder 3.
Fehlermeldungen oder Ergänzungswünsche können gemailt werden an:
Franz Michael Baumann <fm.baumann@uni-muenster.de>

Autor des Grundwörterbuchs:
Bjoern Jacke <bjoern@j3e.de>

Autor der Erweiterung
Franz Michael Baumann <fm.baumann@uni-muenster.de>
