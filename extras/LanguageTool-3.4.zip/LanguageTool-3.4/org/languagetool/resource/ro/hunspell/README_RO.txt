Dicționarul de corectare ortografică
Autori:
    Lucian Constantin (http://rospell.sourceforge.net)
    Sorin Sbarnea (http://www.i18n.ro)
    Alexandru Szasz (Mozilla and OpenOffice.org Romanian Translation Team)
    Ionuț Păduraru (http://www.archeus.ro)
    Adrian Stoica (OpenOffice.org Romanian Translation Team) <adrian dot stoica at cuvinte dot ro>
    Nicu Buculei (OpenOffice.org Romanian Translation Team) <nicu at apsro dot com>
    Cătălin Frâncu (http://dexonline.ro)
    Ionel Mugurel Ciobică (previous aspell releases) <tgakic at sg10 chem tue nl>
    Mihai Budiu (ispell dictionary) <mihaib at cs cmu edu>
Licență:  GPL 2.0/LGPL 2.1/MPL 1.1, vedeți COPYING.GPL, COPYING.LGPL,
    și COPYING.MPL pentru mai multe detalii

Suport:
    Grupul de email rospell la http://groups.google.com/group/rospell

